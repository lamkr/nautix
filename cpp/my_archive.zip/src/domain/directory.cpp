#include "directory_metadata_provider.h"
#include "../core/std.h"
#include "../core/fs.h"

namespace nautix::domain {

    STATIC Directory Directory::from_metadata(const application::DirectoryMetadata&& metadata) {
        return Directory(
            std::move(metadata.path),
            std::move(metadata.name.data()),
            metadata.size,
            metadata.owner_id,
            std::move(metadata.creation_time),
            std::move(metadata.modification_time),
            std::move(metadata.access_time)
        );
    }

    STATIC std::expected<Directory, std::error_code> Directory::home(const application::IDirectoryMetadataProvider& provider) {
        const std::expected<const char*, std::error_code> path = get_home_path();
        if (path.has_value()) {
            std::expected<application::DirectoryMetadata, std::error_code> metadata =
                provider.get_metadata(*path);
            if (metadata.has_value()) {
                return from_metadata(std::move(metadata.value()));
            }
            return std::unexpected(metadata.error());
        }
        return std::unexpected(path.error());
    }

    STATIC std::expected<Directory, std::error_code> Directory::temp(const application::IDirectoryMetadataProvider& provider) {
        const std::expected<fs::path, std::error_code> path = fs::temp_directory_path();
        if (path.has_value()) {
            std::expected<application::DirectoryMetadata, std::error_code> metadata =
                provider.get_metadata(path->c_str());
            if (metadata.has_value()) {
                return from_metadata(std::move(metadata.value()));
            }
            return std::unexpected(metadata.error());
        }
        return std::unexpected(path.error());
    }

    std::expected<std::string, std::error_code> Directory::get_owner_name() const noexcept {
        return ::get_owner_name(owner_id_);
    }

    const std::vector<File>& Directory::files() const noexcept {
        return files_;
    }

    void Directory::add_file(File file) {
        files_.push_back(std::move(file));
    }

}
