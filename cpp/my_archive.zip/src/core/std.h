#pragma once

#define STATIC
